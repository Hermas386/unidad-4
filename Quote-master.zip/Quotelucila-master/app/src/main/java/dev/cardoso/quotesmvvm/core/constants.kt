package dev.cardoso.quotesmvvm.core



const val BASE_URL = "http://192.168.43.205:8080"
const val API_PATH="quotes.php"
const val LOGIN_URL= "/api/v1/users/login"
const val QUOTES_URL= "/api/v1/quotes"